package org.hibernate.validator.referenceguide.chapter10;

import javax.validation.constraints.NotNull;

public class PieceOfLuggage {

	@NotNull
	private String name;

	//getters and setters ...
}
