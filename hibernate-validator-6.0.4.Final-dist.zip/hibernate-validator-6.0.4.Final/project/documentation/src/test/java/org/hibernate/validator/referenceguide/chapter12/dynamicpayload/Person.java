package org.hibernate.validator.referenceguide.chapter12.dynamicpayload;

public class Person {
}

