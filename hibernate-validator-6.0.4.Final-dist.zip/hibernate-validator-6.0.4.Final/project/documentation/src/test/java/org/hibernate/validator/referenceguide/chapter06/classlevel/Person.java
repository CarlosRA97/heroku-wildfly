package org.hibernate.validator.referenceguide.chapter06.classlevel;

public class Person {

	private String name;

	public Person(String name) {
		this.name = name;
	}
}
