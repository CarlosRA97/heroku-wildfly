package org.hibernate.validator.referenceguide.chapter11.cdi.methodvalidation.implicit;

public class Customer {
}
